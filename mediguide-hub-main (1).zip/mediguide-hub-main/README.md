# MediGuide Hub

A comprehensive medicine database application with storage guidelines and dietary recommendations for safe medication use.

## Features

- 📋 Extensive medicine database with detailed information
- 💾 Storage guidelines for proper medication preservation
- 🥗 Dietary recommendations and interactions
- 📱 Responsive design for all devices
- 🔍 Fast and intuitive search functionality
- 🏥 Hospital-themed green design for healthcare vibes

## Technologies

- **Vite** - Next generation frontend tooling
- **React** - UI library
- **TypeScript** - Type-safe JavaScript
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn-ui** - High-quality component library
- **React Router** - Client-side routing
- **React Query** - Data fetching and caching

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn package manager

### Installation

1. Clone the repository:
```sh
git clone https://github.com/shashikumar080305-dev/mediguide-hub.git
cd mediguide-hub
```

2. Install dependencies:
```sh
npm install
```

3. Start the development server:
```sh
npm run dev
```

4. Open http://localhost:8080 in your browser

## Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build for production
- `npm run preview` - Preview production build locally
- `npm run lint` - Run ESLint to check code quality

## Project Structure

```
src/
├── components/     # Reusable React components
├── pages/          # Page components
├── data/           # Medicine database and data files
├── hooks/          # Custom React hooks
├── lib/            # Utility functions
├── App.tsx         # Main app component
└── main.tsx        # Entry point
```

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your GitHub repository
4. Vercel will automatically detect and deploy!

### Manual Build

```sh
npm run build
# Deploy the dist folder to your hosting service
```

## License

MIT License - feel free to use this project however you want.
