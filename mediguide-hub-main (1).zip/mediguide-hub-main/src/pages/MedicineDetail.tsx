import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Pill, AlertTriangle, Thermometer, Apple, Clock } from "lucide-react";
import { medicineDatabase } from "@/data/medicineDatabase";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

const MedicineDetail = () => {
  const { id } = useParams();
  const medicine = medicineDatabase.find((med) => med.id === id);

  if (!medicine) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Medicine not found</h2>
          <Link to="/">
            <Button variant="default">Back to Database</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <Link to="/">
          <Button variant="ghost" className="mb-6 gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Database
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="flex items-start gap-4 mb-8">
            <div className="p-4 rounded-xl bg-accent/10">
              <Pill className="w-8 h-8 text-accent" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-foreground mb-2">{medicine.name}</h1>
              <p className="text-xl text-muted-foreground mb-3">{medicine.genericName}</p>
              <span className="inline-block px-4 py-2 text-sm rounded-full bg-secondary text-secondary-foreground">
                {medicine.category}
              </span>
            </div>
          </div>

          <Card className="p-6 mb-6 bg-card border-border">
            <h2 className="text-2xl font-semibold mb-3 text-foreground">Description</h2>
            <p className="text-muted-foreground leading-relaxed">{medicine.description}</p>
          </Card>

          <Card className="p-6 mb-6 bg-card border-border">
            <h2 className="text-2xl font-semibold mb-4 text-foreground">Dosage Information</h2>
            <p className="text-muted-foreground">{medicine.dosage}</p>
          </Card>

          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <Card className="p-6 bg-card border-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-accent/10">
                  <Apple className="w-5 h-5 text-accent" />
                </div>
                <h2 className="text-2xl font-semibold text-foreground">Diet Recommendations</h2>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-accent" />
                    Timing
                  </h3>
                  <p className="text-muted-foreground text-sm">{medicine.diet.timing}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2">Foods to Avoid</h3>
                  <ul className="space-y-1">
                    {medicine.diet.avoid.map((item, index) => (
                      <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="text-destructive mt-1">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2">Recommended Foods</h3>
                  <ul className="space-y-1">
                    {medicine.diet.recommended.map((item, index) => (
                      <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="text-accent mt-1">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                {medicine.diet.notes && (
                  <div className="pt-3 border-t border-border">
                    <p className="text-sm text-muted-foreground italic">{medicine.diet.notes}</p>
                  </div>
                )}
              </div>
            </Card>

            <Card className="p-6 bg-card border-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-accent/10">
                  <Thermometer className="w-5 h-5 text-accent" />
                </div>
                <h2 className="text-2xl font-semibold text-foreground">Storage Instructions</h2>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Temperature</h3>
                  <p className="text-muted-foreground text-sm">{medicine.storage.temperature}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2">Conditions</h3>
                  <p className="text-muted-foreground text-sm">{medicine.storage.conditions}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2">Shelf Life</h3>
                  <p className="text-muted-foreground text-sm">{medicine.storage.shelfLife}</p>
                </div>
              </div>
            </Card>
          </div>

          <Card className="p-6 mb-6 bg-card border-border">
            <h2 className="text-2xl font-semibold mb-4 text-foreground">Common Side Effects</h2>
            <ul className="grid md:grid-cols-2 gap-2">
              {medicine.sideEffects.map((effect, index) => (
                <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-muted-foreground mt-1">•</span>
                  {effect}
                </li>
              ))}
            </ul>
          </Card>

          <Card className="p-6 bg-destructive/5 border-destructive/20">
            <div className="flex items-center gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-destructive" />
              <h2 className="text-2xl font-semibold text-foreground">Important Warnings</h2>
            </div>
            <ul className="space-y-2">
              {medicine.warnings.map((warning, index) => (
                <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-destructive mt-1">•</span>
                  {warning}
                </li>
              ))}
            </ul>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default MedicineDetail;
