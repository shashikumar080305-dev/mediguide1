export interface Medicine {
  id: string;
  name: string;
  genericName: string;
  category: string;
  description: string;
  dosage: string;
  sideEffects: string[];
  storage: {
    temperature: string;
    conditions: string;
    shelfLife: string;
  };
  diet: {
    avoid: string[];
    recommended: string[];
    timing: string;
    notes: string;
  };
  warnings: string[];
}

export const medicineDatabase: Medicine[] = [
  {
    id: "1",
    name: "Aspirin",
    genericName: "Acetylsalicylic Acid",
    category: "Pain Relief / Antiplatelet",
    description: "Used to reduce pain, fever, and inflammation. Also used to prevent heart attacks and strokes.",
    dosage: "75-325mg daily for cardiovascular protection. 325-650mg every 4-6 hours for pain relief.",
    sideEffects: ["Stomach upset", "Heartburn", "Nausea", "Increased bleeding risk"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep in original container, away from moisture",
      shelfLife: "3-5 years from manufacture date"
    },
    diet: {
      avoid: ["Alcohol", "NSAIDs like ibuprofen", "Vitamin E supplements"],
      recommended: ["Take with food or milk", "Drink plenty of water"],
      timing: "Take with meals to reduce stomach irritation",
      notes: "Avoid on empty stomach. Do not crush enteric-coated tablets."
    },
    warnings: ["Not for children with viral infections", "Consult doctor if pregnant", "May cause allergic reactions"]
  },
  {
    id: "2",
    name: "Metformin",
    genericName: "Metformin Hydrochloride",
    category: "Antidiabetic",
    description: "First-line medication for type 2 diabetes. Helps control blood sugar levels.",
    dosage: "500-2000mg daily, divided into 2-3 doses",
    sideEffects: ["Nausea", "Diarrhea", "Stomach upset", "Metallic taste"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep away from moisture and light",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Excessive alcohol", "High-sugar foods", "Large carbohydrate meals"],
      recommended: ["High-fiber foods", "Lean proteins", "Non-starchy vegetables", "Whole grains"],
      timing: "Take with meals to reduce gastrointestinal side effects",
      notes: "Maintain consistent carbohydrate intake. Monitor blood sugar regularly."
    },
    warnings: ["Can cause lactic acidosis (rare)", "Monitor kidney function", "Stop before surgery"]
  },
  {
    id: "3",
    name: "Lisinopril",
    genericName: "Lisinopril",
    category: "ACE Inhibitor / Blood Pressure",
    description: "Used to treat high blood pressure and heart failure. Helps blood vessels relax.",
    dosage: "10-40mg once daily",
    sideEffects: ["Dry cough", "Dizziness", "Headache", "Fatigue"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep container tightly closed",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["High-sodium foods", "Salt substitutes with potassium", "Excessive potassium supplements"],
      recommended: ["Low-sodium diet", "Fresh fruits and vegetables", "Lean meats"],
      timing: "Can be taken with or without food, same time daily",
      notes: "Avoid sudden position changes to prevent dizziness. Stay hydrated."
    },
    warnings: ["Not for pregnant women", "May cause high potassium levels", "Monitor kidney function"]
  },
  {
    id: "4",
    name: "Atorvastatin",
    genericName: "Atorvastatin Calcium",
    category: "Statin / Cholesterol",
    description: "Reduces cholesterol and triglycerides in the blood. Prevents cardiovascular disease.",
    dosage: "10-80mg once daily",
    sideEffects: ["Muscle pain", "Headache", "Nausea", "Joint pain"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Protect from light and moisture",
      shelfLife: "3 years"
    },
    diet: {
      avoid: ["Grapefruit and grapefruit juice", "Excessive alcohol", "High-fat foods"],
      recommended: ["Heart-healthy diet", "Omega-3 rich foods", "Fiber-rich foods", "Lean proteins"],
      timing: "Can be taken any time of day with or without food",
      notes: "Avoid grapefruit completely. Report muscle pain immediately."
    },
    warnings: ["May cause muscle breakdown", "Monitor liver function", "Avoid during pregnancy"]
  },
  {
    id: "5",
    name: "Omeprazole",
    genericName: "Omeprazole",
    category: "Proton Pump Inhibitor",
    description: "Reduces stomach acid production. Treats GERD, ulcers, and acid reflux.",
    dosage: "20-40mg once daily",
    sideEffects: ["Headache", "Nausea", "Diarrhea", "Stomach pain"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep away from moisture",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Spicy foods", "Acidic foods", "Caffeine", "Alcohol", "Chocolate"],
      recommended: ["Bland foods", "Non-acidic fruits", "Whole grains", "Lean proteins"],
      timing: "Take 30-60 minutes before breakfast on empty stomach",
      notes: "Swallow capsules whole, do not crush or chew. May reduce vitamin B12 absorption."
    },
    warnings: ["Long-term use may affect bone density", "May mask stomach cancer symptoms"]
  },
  {
    id: "6",
    name: "Levothyroxine",
    genericName: "Levothyroxine Sodium",
    category: "Thyroid Hormone",
    description: "Replaces thyroid hormone in people with hypothyroidism.",
    dosage: "25-200mcg once daily, individualized",
    sideEffects: ["Weight changes", "Hair loss", "Tremor", "Anxiety"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Protect from light and moisture",
      shelfLife: "2 years"
    },
    diet: {
      avoid: ["Soy products (within 4 hours)", "High-fiber foods (within 4 hours)", "Calcium supplements (within 4 hours)", "Iron supplements (within 4 hours)"],
      recommended: ["Balanced diet", "Adequate iodine", "Selenium-rich foods"],
      timing: "Take on empty stomach, 30-60 minutes before breakfast",
      notes: "Very sensitive to timing and food interactions. Take consistently."
    },
    warnings: ["Regular thyroid monitoring required", "Dose adjustments needed", "Not for weight loss"]
  },
  {
    id: "7",
    name: "Amlodipine",
    genericName: "Amlodipine Besylate",
    category: "Calcium Channel Blocker",
    description: "Treats high blood pressure and chest pain (angina). Relaxes blood vessels.",
    dosage: "2.5-10mg once daily",
    sideEffects: ["Swelling of ankles/feet", "Dizziness", "Flushing", "Headache"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep away from light",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Grapefruit juice", "High-sodium foods", "Excessive alcohol"],
      recommended: ["Low-sodium diet", "Potassium-rich foods", "Heart-healthy foods"],
      timing: "Same time each day, with or without food",
      notes: "May take 2-4 weeks for full effect. Avoid sudden position changes."
    },
    warnings: ["May cause ankle swelling", "Not for severe aortic stenosis"]
  },
  {
    id: "8",
    name: "Albuterol",
    genericName: "Albuterol Sulfate",
    category: "Bronchodilator / Asthma",
    description: "Relieves bronchospasm in asthma and COPD. Quick-relief inhaler.",
    dosage: "2 puffs every 4-6 hours as needed",
    sideEffects: ["Tremor", "Nervousness", "Headache", "Rapid heartbeat"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Do not puncture or burn, even when empty",
      shelfLife: "Check expiration date on inhaler"
    },
    diet: {
      avoid: ["Excessive caffeine", "Energy drinks"],
      recommended: ["Plenty of water", "Anti-inflammatory foods", "Vitamin D-rich foods"],
      timing: "Use as needed for symptoms or before exercise",
      notes: "Rinse mouth after use. Not for daily maintenance without controller medication."
    },
    warnings: ["Seek immediate care if not improving", "Overuse indicates poor control"]
  },
  {
    id: "9",
    name: "Sertraline",
    genericName: "Sertraline Hydrochloride",
    category: "SSRI Antidepressant",
    description: "Treats depression, anxiety disorders, OCD, PTSD, and panic disorder.",
    dosage: "50-200mg once daily",
    sideEffects: ["Nausea", "Insomnia", "Drowsiness", "Sexual side effects", "Dry mouth"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep tightly closed, away from moisture",
      shelfLife: "3 years"
    },
    diet: {
      avoid: ["Excessive alcohol", "MAO inhibitors", "St. John's Wort"],
      recommended: ["Balanced diet", "Omega-3 fatty acids", "Regular meals"],
      timing: "Morning or evening, same time daily, with or without food",
      notes: "May take 4-6 weeks for full effect. Don't stop abruptly."
    },
    warnings: ["Monitor for suicidal thoughts initially", "Serotonin syndrome risk", "Gradual discontinuation needed"]
  },
  {
    id: "10",
    name: "Gabapentin",
    genericName: "Gabapentin",
    category: "Anticonvulsant / Nerve Pain",
    description: "Treats nerve pain and seizures. Also used for restless leg syndrome.",
    dosage: "300-3600mg daily in divided doses",
    sideEffects: ["Dizziness", "Drowsiness", "Fatigue", "Coordination problems"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep in original container",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Alcohol", "Antacids (within 2 hours)"],
      recommended: ["Regular meals", "Adequate hydration"],
      timing: "Usually 3 times daily with or without food",
      notes: "Don't stop suddenly. May cause drowsiness - avoid driving initially."
    },
    warnings: ["May cause dependence", "Gradual tapering required", "May worsen depression"]
  },
  {
    id: "11",
    name: "Prednisone",
    genericName: "Prednisone",
    category: "Corticosteroid",
    description: "Reduces inflammation. Treats allergies, arthritis, asthma, and autoimmune conditions.",
    dosage: "5-60mg daily, highly variable",
    sideEffects: ["Weight gain", "Mood changes", "Increased appetite", "Insomnia", "High blood sugar"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Protect from light and moisture",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["High-sodium foods", "Simple sugars", "Alcohol"],
      recommended: ["Calcium-rich foods", "Vitamin D", "Protein", "Potassium-rich foods"],
      timing: "Take with food in morning to mimic natural cortisol",
      notes: "Never stop abruptly. May increase blood sugar. Monitor weight and blood pressure."
    },
    warnings: ["Weakens immune system", "May cause bone loss", "Requires gradual tapering"]
  },
  {
    id: "12",
    name: "Warfarin",
    genericName: "Warfarin Sodium",
    category: "Anticoagulant",
    description: "Blood thinner that prevents blood clots. Used for atrial fibrillation, DVT, PE.",
    dosage: "Individualized, 2-10mg daily based on INR",
    sideEffects: ["Bleeding", "Bruising", "Nausea", "Hair loss"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Protect from light",
      shelfLife: "3 years"
    },
    diet: {
      avoid: ["Vitamin K-rich foods in inconsistent amounts", "Cranberry products", "Alcohol", "Grapefruit juice"],
      recommended: ["Consistent vitamin K intake", "Green leafy vegetables in stable amounts"],
      timing: "Same time each day, usually evening",
      notes: "Regular INR monitoring essential. Maintain consistent diet. Report any bleeding."
    },
    warnings: ["High bleeding risk", "Many drug interactions", "Pregnancy category X"]
  },
  {
    id: "13",
    name: "Hydrocodone",
    genericName: "Hydrocodone/Acetaminophen",
    category: "Opioid Analgesic",
    description: "Treats moderate to severe pain. Combination with acetaminophen.",
    dosage: "5-10mg every 4-6 hours as needed",
    sideEffects: ["Drowsiness", "Constipation", "Nausea", "Dizziness"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Secure location, away from children",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Alcohol", "Grapefruit juice", "Other CNS depressants"],
      recommended: ["High-fiber foods for constipation", "Plenty of water", "Stool softeners"],
      timing: "With or without food, every 4-6 hours as needed",
      notes: "Highly addictive. Use exactly as prescribed. Don't exceed acetaminophen limit (4g/day)."
    },
    warnings: ["Risk of addiction and abuse", "Respiratory depression", "Controlled substance"]
  },
  {
    id: "14",
    name: "Azithromycin",
    genericName: "Azithromycin",
    category: "Antibiotic / Macrolide",
    description: "Treats bacterial infections including respiratory, skin, ear, and STIs.",
    dosage: "250-500mg once daily for 3-5 days",
    sideEffects: ["Nausea", "Diarrhea", "Abdominal pain", "Vomiting"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep away from moisture",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Antacids (within 2 hours)", "Dairy products may reduce absorption"],
      recommended: ["Probiotics to prevent diarrhea", "Adequate hydration", "Light meals"],
      timing: "Can be taken with or without food, same time daily",
      notes: "Complete full course even if feeling better. Z-Pack is common 5-day course."
    },
    warnings: ["May cause heart rhythm problems", "Not for liver disease", "Complete full course"]
  },
  {
    id: "15",
    name: "Losartan",
    genericName: "Losartan Potassium",
    category: "ARB / Blood Pressure",
    description: "Treats high blood pressure and protects kidneys in diabetes.",
    dosage: "25-100mg once or twice daily",
    sideEffects: ["Dizziness", "Upper respiratory infection", "Back pain", "Fatigue"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Protect from light",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["High-sodium foods", "Potassium supplements", "Salt substitutes"],
      recommended: ["Low-sodium diet", "Heart-healthy foods", "Adequate hydration"],
      timing: "Same time daily, with or without food",
      notes: "May take several weeks for full effect. Monitor blood pressure regularly."
    },
    warnings: ["Not during pregnancy", "Monitor potassium levels", "May affect kidney function"]
  },
  {
    id: "16",
    name: "Montelukast",
    genericName: "Montelukast Sodium",
    category: "Leukotriene Inhibitor / Asthma",
    description: "Prevents asthma attacks and treats seasonal allergies. Long-term control medication.",
    dosage: "4-10mg once daily (age-dependent)",
    sideEffects: ["Headache", "Stomach pain", "Fatigue", "Mood changes"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep away from moisture",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["No specific food interactions"],
      recommended: ["Anti-inflammatory diet", "Omega-3 fatty acids"],
      timing: "Evening, with or without food",
      notes: "Not for acute asthma attacks. Keep rescue inhaler available."
    },
    warnings: ["Monitor for mood/behavior changes", "Rare psychiatric events reported"]
  },
  {
    id: "17",
    name: "Tramadol",
    genericName: "Tramadol Hydrochloride",
    category: "Opioid-like Analgesic",
    description: "Treats moderate to moderately severe pain. Less potent than traditional opioids.",
    dosage: "50-100mg every 4-6 hours as needed",
    sideEffects: ["Dizziness", "Nausea", "Constipation", "Drowsiness"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Secure storage",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Alcohol", "Other CNS depressants"],
      recommended: ["High-fiber foods", "Plenty of water"],
      timing: "Every 4-6 hours as needed, with or without food",
      notes: "Risk of seizures at high doses. Can be habit-forming."
    },
    warnings: ["Seizure risk", "Serotonin syndrome possible", "Controlled substance"]
  },
  {
    id: "18",
    name: "Clopidogrel",
    genericName: "Clopidogrel Bisulfate",
    category: "Antiplatelet",
    description: "Prevents blood clots after heart attack, stroke, or stent placement.",
    dosage: "75mg once daily",
    sideEffects: ["Bleeding", "Bruising", "Nosebleeds", "Rash"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep in original container",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["NSAIDs if possible", "Excessive alcohol"],
      recommended: ["Heart-healthy diet", "Omega-3 fatty acids"],
      timing: "Same time daily, with or without food",
      notes: "Don't stop without doctor approval, especially after stent. May take 5-7 days to stop working."
    },
    warnings: ["Increased bleeding risk", "Stop before surgery", "Proton pump inhibitors may reduce effectiveness"]
  },
  {
    id: "19",
    name: "Furosemide",
    genericName: "Furosemide",
    category: "Loop Diuretic / Water Pill",
    description: "Treats fluid retention (edema) and high blood pressure.",
    dosage: "20-80mg once or twice daily",
    sideEffects: ["Increased urination", "Dizziness", "Dehydration", "Low potassium"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Protect from light",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Excessive sodium", "Licorice", "Alcohol"],
      recommended: ["Potassium-rich foods (bananas, oranges)", "Adequate hydration", "Balanced electrolytes"],
      timing: "Morning or early afternoon to avoid nighttime urination",
      notes: "Monitor weight daily. May cause frequent urination within 6 hours of dose."
    },
    warnings: ["May cause electrolyte imbalances", "Monitor potassium levels", "Can worsen gout"]
  },
  {
    id: "20",
    name: "Metoprolol",
    genericName: "Metoprolol Succinate/Tartrate",
    category: "Beta Blocker",
    description: "Treats high blood pressure, chest pain, and heart failure. Slows heart rate.",
    dosage: "25-200mg once or twice daily",
    sideEffects: ["Fatigue", "Dizziness", "Slow heartbeat", "Cold hands/feet"],
    storage: {
      temperature: "Room temperature (20-25°C)",
      conditions: "Keep away from moisture",
      shelfLife: "2-3 years"
    },
    diet: {
      avoid: ["Sudden discontinuation", "Excessive alcohol"],
      recommended: ["Heart-healthy diet", "Regular meals"],
      timing: "Same time daily with or just after meals",
      notes: "Don't stop abruptly - can cause rebound high blood pressure. May mask low blood sugar."
    },
    warnings: ["Not for asthma patients", "Gradual discontinuation required", "May worsen heart failure initially"]
  }
];
