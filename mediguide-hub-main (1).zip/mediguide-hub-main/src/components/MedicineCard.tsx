import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Pill, ChevronRight } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Medicine } from "@/data/medicineDatabase";

interface MedicineCardProps {
  medicine: Medicine;
  index: number;
}

export const MedicineCard = ({ medicine, index }: MedicineCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Link to={`/medicine/${medicine.id}`}>
        <Card className="p-6 hover:shadow-lg transition-all duration-300 border-border bg-card group cursor-pointer">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4 flex-1">
              <div className="p-3 rounded-lg bg-accent/10">
                <Pill className="w-5 h-5 text-accent" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-foreground mb-1 group-hover:text-accent transition-colors">
                  {medicine.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-2">{medicine.genericName}</p>
                <span className="inline-block px-3 py-1 text-xs rounded-full bg-secondary text-secondary-foreground">
                  {medicine.category}
                </span>
                <p className="text-sm text-muted-foreground mt-3 line-clamp-2">
                  {medicine.description}
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-accent group-hover:translate-x-1 transition-all" />
          </div>
        </Card>
      </Link>
    </motion.div>
  );
};
